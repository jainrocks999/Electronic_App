export default ImagePath = { 
    Path: 'https://ecom.craftsweb.co.in/public/storage/',
    Path1: 'https://api.myjeweller.in',
    path2: `https://olocker.co/`,
  };
  