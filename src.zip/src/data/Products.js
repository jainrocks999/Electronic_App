export const Products=[
    {
        image:require('../assests/image1.png'),
        name:'Casio Digital Keyboad',
        price :'₹12,995',
        desc:'Its products include calculators, mobile phones, digital cameras, electronic musical instruments, and analogue and digital watches.'
    },
    {
        image:require('../assests/mobile.png'),
        name:'Apple iPhone 14 Pro',
        price :'₹179,900',
        desc:'The iPhone runs the iOS operating system, and in 2021 when the iPhone 13 was introduced, it offered up to 1 TB of storage and a 12-megapixel camera.'
    },
    {
        image:require('../assests/watch.png'),
        name:'Symphony Air Cooler ',
        price :'₹6,199',
        desc:'a portable timepiece intended to be carried or worn by a person. It is designed to keep a consistent movement despite the motions caused by the persons activities.'
    },
    {
        image:require('../assests/pyano.png'),
        name:'Ariel Detergent Powder ',
        price :'₹660',
        desc:'standards of rhythm, melody, and, in most Western music, harmony. Both the simple folk song and the complex electronic composition belong to the same activity, music.'
    },
    {
        image:require('../assests/mobile.png'),
        name:'Cello Laundry Basket',
        price :'₹789',
        desc:'While most baskets are made from plant materials, other materials such as horsehair, baleen, or metal wire can be used. Baskets are generally woven by hand.'
    },
    {
        image:require('../assests/watch.png'),
        name:'Cello Laundry Basket',
        price :'₹789',
        desc:'While most baskets are made from plant materials, other materials such as horsehair, baleen, or metal wire can be used. Baskets are generally woven by hand.'
    },
    
    {
        image:require('../assests/image1.png'),
        name:'Godrej Washing Machine',
        price :'₹18,500',
        desc:'machines that use water as opposed to dry cleaning (which uses alternative cleaning fluids and is performed by specialist businesses) or ultrasonic cleaners.'
    },
    
]