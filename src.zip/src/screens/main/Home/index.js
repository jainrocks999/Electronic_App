import React, {useEffect, useState} from 'react';
import {
  View,
  Text,
  SafeAreaView,
  ScrollView,
  Image,
  TextInput,
  FlatList,
  TouchableOpacity,
  Platform,
  Alert,
  BackHandler,
} from 'react-native';
import styles from './Styles';
import AntDesign from 'react-native-vector-icons/AntDesign';
import Carousel, {Pagination} from 'react-native-snap-carousel';
import {SliderBox} from 'react-native-image-slider-box';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
import Cat from '../../../data/Cat';
import Card from '../../../compoents/Card';
import {Products} from '../../../data/Products';
import Header from '../../../compoents/Header';
import {useIsFocused, useNavigation} from '@react-navigation/native';
import BottumTab from '../../../compoents/BottumTab';
import {TouchableWithoutFeedback} from 'react-native';
import Anty from 'react-native-vector-icons/AntDesign';
import {useDispatch, useSelector} from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';
import he from 'he'; // Import the 'he' library for HTML entity decoding
import Loader from '../../../compoents/Loader';
import {
  product,
  category,
  addwishlist1,
  productDetail,
  Banner,
  brands,
  brandcategory,
} from '../../../redux/slice/Homesclice';
import Toast from 'react-native-simple-toast';
import Imagepath from '../../../compoents/Imagepath';
import {profiledata} from '../../../redux/slice/AddressSclice';
import {orderlistapi} from '../../../redux/slice/orderSclice';
let backPress = 0;
const Home = () => {
  const products = useSelector(state => state.home?.product);
  const data = useSelector(state => state.home?.Categories);
  const silder1 = useSelector(state => state.home?.Bannerdata);

  const data1 = useSelector(state => state?.home?.Brand);
  const navigation = useNavigation();
  const loading = useSelector(state => state.home.loading);
  const loading1 = useSelector(state => state?.order?.loading);

  const focus = useIsFocused();

  const [activeSlide, setActiveSlide] = useState(0);
  const dispatch = useDispatch();
  const silder = [
    require('../../../assests/iphone.jpeg'),
    require('../../../assests/macbook.jpeg'),
  ];
  const isFocus = useIsFocused();

  useEffect(() => {
    if (focus) {
      apicall();
    }
  }, [focus]);

  const apicall = async () => {
    try {
      // Retrieve token and user_id from AsyncStorage
      const token = await AsyncStorage.getItem('Token');
      const userid = await AsyncStorage.getItem('user_id');

      if (!token || !userid) {
        console.error('Token or User ID is missing.');
        return;
      }

      await dispatch(Banner({id: userid, token: token, url: 'home-slider'}));
      await dispatch(product({id: userid, token: token, url: 'products'}));
      await dispatch(brands({id: userid, token: token, url: 'product-brand'}));
      await dispatch(
        orderlistapi({id: userid, token: token, url: 'fetch-order'}),
      );

      await dispatch(
        category({id: userid, token: token, url: 'product-category'}),
      );
      await dispatch(
        profiledata({id: userid, token: token, url: 'profile-list'}),
      );
    } catch (error) {
      console.error('Error in API call:', error);
    }
  };

  const removeHtmlTags = str => {
    return str?.replace(/<\/?[^>]+(>|$)/g, '');
  };

  useEffect(() => {
    const backHandler = BackHandler.addEventListener(
      'hardwareBackPress',
      handleBackButtonClick,
    );
    return () => backHandler.remove();
  }, []);

  const handleBackButtonClick = () => {
    if (navigation.isFocused()) {
      if (backPress > 0) {
        BackHandler.exitApp();
        backPress = 0;
      } else {
        backPress++;
        Toast.show('Press again to exit app');
        setTimeout(() => {
          backPress = 0;
        }, 2000);
        BackHandler.removeEventListener('hardwareBackPress');
      }
      return true;
    }
  };

  const addWishList = async item => {
    const token = await AsyncStorage.getItem('Token');
    const userid = await AsyncStorage.getItem('user_id');
    await dispatch(
      addwishlist1({
        user: userid,
        id: item.id,
        token: token,
        isadd: item.is_wishlist,
        url: 'wishlist-product-add',
      }),
    );
  };
  const handleDetail = async item => {
    const token = await AsyncStorage.getItem('Token');
    const userid = await AsyncStorage.getItem('user_id');
    await dispatch(
      productDetail({
        user: userid,
        id: item.id,
        token: token,

        url: 'fetch-single-product',
        navigation,
      }),
    );
  };
  const brandscategories = async item => {
    const token = await AsyncStorage.getItem('Token');
    const userid = await AsyncStorage.getItem('user_id');

    await dispatch(
      brandcategory({
        user: userid,
        id: item.id,
        token: token,

        url: 'brand-by-product',
        navigation,
        nav: true,
      }),
    );
  };

  return (
    <View style={{flex: 1, backgroundColor: '#18314F'}}>
      <Header />
      {loading || loading1 ? <Loader /> : null}
      <ScrollView
        style={{width: '100%', backgroundColor: '#ffffff'}}
        contentContainerStyle={{}}
        showsVerticalScrollIndicator={false}>
        <View style={styles.conatainer}>
          <FlatList
            data={
              Array.isArray(silder1?.data) ? silder1?.data[0].slider_items : []
            }
            dotColor="#fddae8"
            horizontal
            showsHorizontalScrollIndicator={false}
            pagingEnabled
            keyExtractor={(item, index) => index.toString()}
            renderItem={({item}) => {
              return (
                <View style={styles.photos}>
                  {/* <View style={styles.con}> */}

                  <View style={styles.img2}>
                    <Image
                      style={styles.image}
                      source={
                        item.image
                          ? {uri: `${Imagepath.Path}${item.image}`}
                          : require('../../../assests/noimg.jpeg')
                      }
                    />
                    {/* </View> */}
                  </View>
                </View>
              );
            }}
          />
        </View>

        <View
          style={{
            height: hp(5),
            width: wp(100),
            backgroundColor: 'white',
            marginVertical: 20,
            justifyContent: 'center',
          }}>
          <View style={styles.titleContainer}>
            <Text style={styles.category}>Top Categories</Text>
            <Text
              onPress={() => navigation.navigate('Categories')}
              style={[
                styles.category,
                {
                  color: '#18314F',
                  fontWeight: '400',
                  textDecorationLine: 'underline',
                  fontSize: wp(4),
                  marginRight: 20,
                },
              ]}>
              See All
            </Text>
          </View>
        </View>
        <View
          style={{
            width: '100%',
            backgroundColor: 'white',
            height: hp('20%'),
            justifyContent: 'center',
            //  alignItems: 'center',
            shadowColor: '#000',
            shadowOffset: {
              width: 0,
              height: 2,
            },
            shadowOpacity: 0.15,
            shadowRadius: 0.84,
            elevation: 1,
          }}>
          <View style={{}}>
            <FlatList
              data={data?.slice(0, 4)}
              showsHorizontalScrollIndicator={false}
              horizontal
              renderItem={({item, index}) => {
                if (index === 1) {
                }
                return (
                  <View style={styles.cardsView}>
                    <View style={styles.imagecontainer}>
                      <TouchableOpacity
                        onPress={() =>
                          navigation.navigate('Subcategory', {item})
                        }>
                        <Image
                          style={styles.images}
                          source={
                            item.image
                              ? {uri: `${Imagepath.Path}${item.image}`}
                              : require('../../../assests/noimg.jpeg')
                          }
                        />
                      </TouchableOpacity>
                    </View>
                    <Text style={styles.txt2}>{item.name}</Text>
                  </View>
                );
              }}
            />
          </View>
        </View>

        <View
          style={{
            height: hp(5),
            width: wp(100),
            backgroundColor: 'white',
            marginVertical: 20,
            justifyContent: 'center',
          }}>
          <View style={styles.titleContainer}>
            <Text style={styles.category}>Featured Brands</Text>
            <Text
              onPress={() => navigation.navigate('Categories1')}
              style={[
                styles.category,
                {
                  color: '#18314F',
                  fontWeight: '400',
                  textDecorationLine: 'underline',
                  fontSize: wp(4),
                  marginRight: 20,
                },
              ]}>
              See All
            </Text>
          </View>
        </View>
        <View
          style={{
            width: '100%',
            backgroundColor: 'white',
            height: hp('20%'),
            justifyContent: 'center',
            //  alignItems: 'center',
            shadowColor: '#000',
            shadowOffset: {
              width: 0,
              height: 2,
            },
            shadowOpacity: 0.15,
            shadowRadius: 0.84,
            elevation: 1,
          }}>
          <View style={{}}>
            <FlatList
              data={Array.isArray(data1) ? data1?.slice(0, 4) : []}
              showsHorizontalScrollIndicator={false}
              horizontal
              renderItem={({item, index}) => {
                if (index === 1) {
                }
                return (
                  <View style={styles.cardsView}>
                    <View style={styles.imagecontainer}>
                      <TouchableOpacity
                        onPress={
                          () => brandscategories(item)

                          // navigation.navigate('Subcategory1', { item })
                        }>
                        <Image
                          style={[styles.images, {resizeMode: 'contain'}]}
                          source={
                            item.logo
                              ? {uri: `${Imagepath.Path}${item.logo}`}
                              : require('../../../assests/noimg.jpeg')
                          }
                        />
                      </TouchableOpacity>
                    </View>
                    <Text style={styles.txt2}>{item.name}</Text>
                  </View>
                );
              }}
            />
          </View>
        </View>

        <View
          style={{
            height: hp(5),
            width: '100%',
            backgroundColor: 'white',
            marginVertical: 20,
          }}>
          <View style={[styles.titleContainer]}>
            <Text style={[styles.category]}>Essential Products</Text>
            <Text
              onPress={() => navigation.navigate('ProductList')}
              style={[
                styles.category,
                {
                  color: '#0f3a8d',
                  fontWeight: '400',
                  textDecorationLine: 'underline',
                  fontSize: wp(4),
                  marginRight: 20,
                },
              ]}>
              See All
            </Text>
          </View>
        </View>
        <FlatList
          data={products?.slice(0, 4)}
          // onEndReached={() => {}}
          // onEndReachedThreshold={1}
          numColumns={2}
          keyExtractor={(item, index) => index?.toString()}
          renderItem={({item, index}) => {
            return (
              <View style={styles.cardView}>
                <View style={styles.imgcontainer}>
                  <TouchableOpacity
                    style={{
                      position: 'absolute',
                      top: 5,
                      right: 0,
                      left: 5,
                      zIndex: 10,
                      height: hp(3),
                      width: wp(8),
                    }}
                    onPress={() => addWishList(item)}>
                    <AntDesign
                      name="hearto"
                      style={[
                        styles.iconic,
                        {color: item.is_wishlist ? 'red' : 'grey'},
                      ]}
                    />
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => handleDetail(item)}>
                    <Image
                      style={styles.img}
                      source={{uri: `${Imagepath.Path}${item.image}`}}
                    />
                  </TouchableOpacity>
                </View>
                <Text style={styles.txt2}>{item.name}</Text>
                <View style={{marginTop: 15, marginHorizontal: 5}}>
                  <Text>
                    {removeHtmlTags(item.description)
                      ?.split('\n')
                      .filter(line => line.trim())[0]
                      ?.substring(0, 30)}{' '}
                    ...{' '}
                  </Text>
                </View>
                <View style={styles.priceCOntainer}>
                  {item.special ? (
                    <>
                      <Text style={[styles.Price, {color: 'black'}]}>
                        ₹ {item.special}
                      </Text>
                      <Text
                        style={[
                          styles.Price,
                          {
                            textDecorationLine: 'line-through',
                            fontSize: wp(3),
                            marginTop: 2,
                            fontWeight: 'bold',
                            color: 'red',
                          },
                        ]}>
                        ₹ {item.sale_price}
                      </Text>
                    </>
                  ) : (
                    <Text style={[styles.Price, {color: 'black'}]}>
                      ₹ {item.sale_price}
                    </Text>
                  )}
                  <Text
                    style={[
                      {
                        fontSize: wp(3),
                        marginTop: 2,
                        fontWeight: 'bold',
                        color: 'grey',
                      },
                    ]}>
                    Ex Tax:{' '}
                    <Text style={{textDecorationLine: 'line-through'}}>
                      ₹ {item.price}
                    </Text>
                  </Text>
                </View>
              </View>
            );
          }}
        />
      </ScrollView>
      <BottumTab />
    </View>
  );
};
export default Home;
