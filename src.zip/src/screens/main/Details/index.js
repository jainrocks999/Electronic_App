import React, {useEffect, useState} from 'react';
import {
  FlatList,
  ScrollView,
  Text,
  TouchableOpacity,
  View,
  TextInput,
  Image,
  alert,
  Alert,
  Modal,
  KeyboardAvoidingView,
} from 'react-native';
import {SliderBox} from 'react-native-image-slider-box';
import Input from '../../../compoents/Input';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
import styles from './styles';
import EvilIcons from 'react-native-vector-icons/EvilIcons';
import AntDesign from 'react-native-vector-icons/AntDesign';
import BottumTab from '../../../compoents/BottumTab';
import Entypo from 'react-native-vector-icons/Entypo';
import DatePicker from 'react-native-date-picker';
import {WebView} from 'react-native-webview';
import CheckBox from 'react-native-check-box';
import CustomCheckbox from '../../../compoents/checkbox';
import {useDispatch, useSelector} from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';
import he from 'he';
import DocumentPicker from 'react-native-document-picker';
import Stars from 'react-native-stars';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Loader from '../../../compoents/Loader';
import Imagepath from '../../../compoents/Imagepath';
import {
  addToCard,
  addwishlist1,
  brandcategory,
  productDetail,
  productsbycategories,
  searchQ,
} from '../../../redux/slice/Homesclice';

const removeHtmlTags = str => {
  return str?.replace(/<\/?[^>]+(>|$)/g, '') || ''; // Remove HTML tags
};

const Details = ({route, navigation}) => {
  const [quantity, setQuantity] = useState('');
  const detail = useSelector(state => state.home?.ProductDetails[0]);
  const quant=useSelector(state=>state?.home?.addToCard1)
  const isLoading = useSelector(state => state.home?.loading);

  const [readTxt, setreadTxt] = useState(false);
  const option = detail?.options;

  let img1 = [];
  detail?.images?.forEach(item => {
    let image = `${Imagepath.Path}${item}`;
    img1.push(image);
  });


  const dispatch = useDispatch();
  const addCart = async () => {
    const token = await AsyncStorage.getItem('Token');
    const userid = await AsyncStorage.getItem('user_id');
    await dispatch(
      addToCard({
        user: userid,
        id: detail?.id,
        qty:1,
        // qty:quant?.qty==undefined? 1:quant?.qty+1,
        token: token,

        url: 'add-to-cart',
        //  navigation,
      }),
    );
  };
  const [rating, setRating] = useState(1);
  const [isSelected, setSelection] = useState(false);

  const [selectedOptions, setSelectedOptions] = useState({});

  const toggleSelection = optionId => {
    setSelectedOptions(prev => ({
      ...prev,
      [optionId]: !prev[optionId],
    }));
  };

  const [message, setMessage] = useState('');
  const [textarea, settextarea] = useState('');

  const [Time, settime] = useState('');
  const [Uploadfile, setuploadfile] = useState('');
  const [Timedate, settimedate] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [open, setOpen] = useState(false);
  const [dob, setDob] = useState('');
  const [date, setDate] = useState(new Date());

  const handleDateChange = date => {
    setSelectedDate(date);
  };
  const [modalVisible, setModalVisible] = useState(false);
  const [dateInputValue, setDateInputValue] = useState('');
  const onChangeDate = (event, selectedDate) => {
    const currentDate = selectedDate || new Date();
    setShowDatePicker(false);
    setSelectedDate(currentDate);
    setDateInputValue(currentDate.toISOString());
  };
  const showDatepicker = () => {
    setShowDatePicker(true);
  };

  const [fileResponse, setFileResponse] = useState(null);
  const [image1, setImage1] = useState('');

  const handleDocumentSelection = async () => {
    try {
      const response = await DocumentPicker.pick({
        type: [DocumentPicker.types.allFiles],
      });
      setFileResponse(response);
    } catch (err) {
      if (DocumentPicker.isCancel(err)) {
      } else {
        throw err;
      }
    }
  };

  const [isLoading1, setIsLoading] = useState(false);
  const addWishList = async () => {
    try {
      setIsLoading(true);
      const token = await AsyncStorage.getItem('Token');
      const userid = await AsyncStorage.getItem('user_id');
      const query = await AsyncStorage.getItem('query');

      await dispatch(
        addwishlist1({
          user: userid,
          id: detail.id,
          token: token,
          isadd: detail.is_wishlist,
          url: 'wishlist-product-add',
        }),
      );

      {
        isLoading == false
          ? await dispatch(
              brandcategory({
                user: userid,
                id: detail.brand_id,
                token: token,

                url: 'brand-by-product',
                navigation,
                nav: false,
              }),
            )
          : null;
      }
      {
        query != null
          ? dispatch(
              searchQ({
                userid: userid,
                q: query,
                url: 'products-search',
                token: token,
              }),
            )
          : null;
      }
      handleDetail();
      {
        isLoading == false ? hanndleProduct() : null;
      }
    } catch (error) {
      console.error('Error in adding wishlist:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const hanndleProduct = async item => {
    const token = await AsyncStorage.getItem('Token');
    const userid = await AsyncStorage.getItem('user_id');

    await dispatch(
      productsbycategories({
        id: userid,
        token: token,
        category: detail?.p_category_id,
        url: 'category-by-product',
        navigation,
      }),
    );
  };

  const handleDetail = async () => {
    const token = await AsyncStorage.getItem('Token');
    const userid = await AsyncStorage.getItem('user_id');
    await dispatch(
      productDetail({
        user: userid,
        id: detail?.id,
        token: token,

        url: 'fetch-single-product',
        navigation,
      }),
    );
  };

  const getProcessedText = () => {
    const text = removeHtmlTags(detail?.description)
      ?.split('\n')
      ?.filter(line => line.trim())[0];

    return !readTxt ? text?.substring(0, 80) + '...' : text;
  };

  const handleImagePress = index => {
    const pressedImageUrl = img1[index];
    console.log('dahndhdsa', pressedImageUrl);
    setSelection(true);
    setQuantity(pressedImageUrl);
    //  Alert.alert(`Image URL: ${pressedImageUrl}`);
  };

  return (
    <View style={{flex: 1, backgroundColor: '#e6f0f2'}}>
      {isLoading || isLoading1 ? <Loader /> : null}
      <View style={styles.header}>
        <View style={styles.back}>
          <AntDesign
            onPress={() => navigation.goBack()}
            name="arrowleft"
            size={wp(5.9)}
            color="white"
          />
          <View
            style={{
              width: wp(100),
              paddingHorizontal: wp(2),
            }}>
            <Text style={{fontSize: wp(4.5), color: 'white'}}>
              Categories Detail
            </Text>
          </View>
        </View>
      </View>
      <ScrollView contentContainerStyle={{}}>
        <View style={{marginTop: hp(2)}}>
          <SliderBox
            style={{
              height: hp(40),
              width: wp(93),
              borderRadius: 5,
              alignSelf: 'center',
              backgroundColor: 'white',
            }}
            images={img1}
            resizeMode="contain"
            dotColor="#fddae8"
            inactiveDotColor="#cccccc"
            ImageComponentStyle={{}}
            onCurrentImagePressed={index => handleImagePress(index)}
            dotStyle={{
              width: wp(5),
              height: wp(5),
              borderRadius: 15,
            }}
            imageLoadingColor="#2196F3"
          />
        </View>

        <View style={styles.details}>
          <View
            style={[
              styles.name,
              {
                alignSelf: 'center',
                flexDirection: 'row',
                justifyContent: 'center',
              },
            ]}>
            <Text style={{fontSize: wp(5), fontWeight: '500', color: 'black'}}>
              {detail?.name}
            </Text>
          </View>

          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              marginHorizontal: 20,
            }}>
            <View>
              <Text style={{fontSize: wp(5), color: 'black'}}>
                ₹ {parseFloat(detail?.sale_price).toFixed(2)}
              </Text>
              <Text
                style={[
                  styles.prDeta,
                  {flexDirection: 'row', alignItems: 'center'},
                ]}>
                <Text style={{textDecorationLine: 'line-through'}}>
                  ₹ {parseFloat(detail?.price).toFixed(2)}{' '}
                </Text>{' '}
                MRP incl.of all taxes
              </Text>
            </View>
            <View
              style={{
                alignSelf: 'flex-end',
                alignItems: 'center',
                flexDirection: 'row',
              }}>
              <TouchableOpacity
                style={[styles.btn3, {height: hp(5), width: wp(33)}]}
                onPress={() => {
                  addCart();
                }}>
                <Text
                  style={{fontSize: wp(4), fontWeight: '500', color: 'white'}}>
                  ADD TO CART
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={{
                  // position: 'absolute',
                  // top: 15,
                  // right: 0,
                  // left:15,zIndex:10,
                  height: hp(5),
                  width: wp(8),
                  marginLeft: wp(3),
                }}
                onPress={() => addWishList()}>
                <AntDesign
                  name="hearto"
                  style={[
                    styles.iconic,
                    {
                      fontSize: wp(8),
                      color: detail?.is_wishlist ? 'red' : 'grey',
                    },
                  ]}
                />
              </TouchableOpacity>
            </View>
          </View>
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              marginHorizontal: 20,
              marginTop: hp(2),
            }}>
            <Text style={{fontSize: wp(4), color: 'black'}}>
              Availability - {detail?.stock_status?.label}
            </Text>
          </View>
          {/* <View style={[styles.ratting, {}]}>


          <Stars
        default={rating}    
        count={5}         
        half={true}       
        update={(value) => setRating(value)} 
        fullStar={<Icon name={'star'} style={[styles.myStarStyle]} />} 
        emptyStar={<Icon name={'star-outline'} style={[styles.myStarStyle, styles.myEmptyStarStyle]} />}  // Empty star icon
        halfStar={<Icon name={'star-half-full'} style={[styles.myStarStyle,]} />} 
      />

           
            
          </View> */}
          <View
            style={[
              styles.description,
              {paddingHorizontal: 5, fontSize: wp(15)},
            ]}>
            <Text
              style={{fontWeight: 'bold', fontSize: wp(4), marginBottom: 10}}>
              Description
            </Text>
            <View style={styles.container1}>
              <Text style={styles.contentText1}>
                {getProcessedText()}{' '}
                <Text
                  onPress={() => setreadTxt(prev => !prev)}
                  style={styles.toggleText1}>
                  {!readTxt ? 'Show More..' : 'Show Less..'}
                </Text>
              </Text>
            </View>
          </View>
          {/* <View style={{marginTop:hp(4),alignItems:'center'}}>
          <TouchableOpacity
                style={[styles.btn3, {height: hp(5), width: wp(53)}]}
                onPress={() => {
                  setModalVisible(true)
                 
                }}>
                <Text
                  style={{fontSize: wp(4), fontWeight: '500', color: 'white'}}>
                 Create A Review
                </Text>
              </TouchableOpacity>
         
              </View> */}

          {/* <View style={{marginTop: 50}}>
            <FlatList
              data={option}
              renderItem={({item}) => (
                <View style={{}}>
                  <Text
                    style={{
                      fontWeight: '600',
                      fontSize: 18,
                      marginLeft: 20,
                      marginVertical: 5,
                    }}>
                    {he.decode(item.name)}
                  </Text>
                  <FlatList
                    data={item.product_option_value}
                    horizontal={true}
                    renderItem={({item}) => (
                      <View
                        style={{
                          height: 50,
                          width: 100,
                          margin: 10,

                          alignItems: 'center',
                          flexDirection: 'column',
                          justifyContent: 'space-between',
                        }}>
                       
                        <View style={styles.checkboxContainer}>
                          
                          <CustomCheckbox
                            isSelected={!!selectedOptions[item.option_value_id]} // Convert state to boolean
                            onToggle={() =>
                              toggleSelection(item.option_value_id)
                            } 
                          />
                          <Text style={{fontWeight: '700'}}>
                            {he.decode(item.name)}
                          </Text>
                        </View>
                        <Text>({item.price})</Text>
                      </View>
                    )}
                  />
                </View>
              )}
            />
          </View> */}
          {/* <View style={{marginHorizontal: 15, marginTop: 20}}>
            <Text
              style={{
                fontWeight: '600',
                fontSize: 18,
                marginLeft: 10,
                marginVertical: 5,
              }}>
              {' '}
              Text{' '}
            </Text>
            <TextInput
              style={styles.inputcontainer}
              placeholder="Text"
              label="Text"
              value={message}
              onChangeText={text => setMessage(text)}
              onSubmitEditing={() => alert(`Welcome to ${message}`)}
            />
          </View> */}
          {/* <View style={{marginHorizontal: 15, marginTop: 20}}>
            <Text
              style={{
                fontWeight: '600',
                fontSize: 18,
                marginLeft: 10,
                marginVertical: 5,
              }}>
              {' '}
              Textarea{' '}
            </Text>
            <TextInput
              style={{
                height: hp(20),
                borderRadius: 5,
                marginTop: 10,
                flexDirection: 'row',
                paddingHorizontal: 15,
                borderWidth: 0.5,
              }}
              placeholder="Textarea"
              label="Text"
              value={textarea}
              onChangeText={text => settextarea(text)}
              onSubmitEditing={() => alert(`Welcome to ${message}`)}
            />
          </View> */}
          {/* <View style={{marginHorizontal: 15, marginTop: 20}}>
            <Text
              style={{
                fontWeight: '600',
                fontSize: 18,
                marginLeft: 10,
                marginVertical: 5,
              }}>
              Date
            </Text>
            <TouchableOpacity
                onPress={() => setOpen(true)}
                style={[styles.inputcontainer,{alignItems:'center'}]}>
                 <View style={{marginTop: 0}}>
                  <AntDesign size={18} name='calendar' color={'red'} />
                </View>
                <Text style={styles.txt}>{dob ? dob : 'dd/mm/yyyy'}</Text>
              </TouchableOpacity>
          </View> */}
          {/* <View style={{marginHorizontal: 15, marginTop: 20}}>
            <Text
              style={{
                fontWeight: '600',
                fontSize: 18,
                marginLeft: 10,
                marginVertical: 5,
              }}>
              Time
            </Text>
            <TextInput
              style={styles.inputcontainer}
              placeholder="Time"
              label="Text"
              value={Time}
              onChangeText={text => settime(text)}
              onSubmitEditing={() => alert(`Welcome to ${message}`)}
            />
          </View> */}
          {/* <View style={{marginHorizontal: 15, marginTop: 20}}>
            <Text
              style={{
                fontWeight: '600',
                fontSize: 18,
                marginLeft: 10,
                marginVertical: 5,
              }}>
              Date & Time
            </Text>
            <TextInput
              style={styles.inputcontainer}
              placeholder="Date & Time"
              label="Text"
              value={Timedate}
              onChangeText={text => settimedate(text)}
              onSubmitEditing={() => alert(`Welcome to ${message}`)}
            />
          </View> */}
          {/* <View
            style={{
              marginHorizontal: 15,
              height: hp(50),
              marginTop: 20,
            }}>
            <Text
              style={{
                fontWeight: '600',
                fontSize: 18,
                marginLeft: 10,
                marginVertical: 5,
              }}>
              File
            </Text>
            {fileResponse == null ? (
              <TouchableOpacity
                onPress={() => handleDocumentSelection()}
                style={styles.inputcontainerr}>
                <Text
                  style={{
                    justifyContent: 'center',
                    alignSelf: 'center',
                    paddingHorizontal: 40,
                    color: 'white',
                    fontWeight: '600',
                    fontSize: 15,
                  }}>
                  {' '}
                  Upload file
                </Text>
              </TouchableOpacity>
            ) : (
              <View style={{height: 150, width: 150, borderRadius: 10 ,borderWidth:1}}>
             

               
                
                <Image
                  style={{height: '100%', width: '100%'}}
                  source={{uri: fileResponse[0].uri}}
                    
   
                />
              </View>
            )}
          </View> */}
        </View>
      </ScrollView>

      <DatePicker
        modal
        open={open}
        date={date}
        // date={new Date()}
        mode={'date'}
        maximumDate={new Date()}
        onConfirm={date => {
          setOpen(false);
          var d = date;
          (month = '' + (d.getMonth() + 1)),
            (day = '' + d.getDate()),
            (day1 = '' + d.getDate() + 1),
            (year = d.getFullYear());

          if (month.length < 2) month = '0' + month;

          if (day.length < 2) day = '0' + day;

          var finalDate = [day, month, year].join('/');
          setDob(finalDate);
        }}
        onCancel={() => {
          setOpen(false);
        }}
      />

      <Modal
        // animationType="slide"
        // transparent={false}
        visible={isSelected}
        onRequestClose={() => setSelection(false)} // Close modal on back press
      >
        <View style={styles.modalContainer}>
          <Image
            source={{uri: quantity}}
            style={styles.fullImage} // Full-screen style
            resizeMode="contain" // Adjusts the image to fit within the screen
          />
          <TouchableOpacity
            style={styles.closeButton1}
            onPress={() => setSelection(false)}>
            <Text
              style={{fontSize: wp(4.5), color: '#fff', textAlign: 'right'}}>
              cancel
            </Text>
          </TouchableOpacity>
        </View>
      </Modal>
      <Modal
        visible={modalVisible}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setModalVisible(false)}>
        {/* {isLoading ? <Loader /> : null} */}
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
          style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            {/* Close Icon */}

            <TouchableOpacity
              onPress={() => setModalVisible(false)}
              style={[styles.closeButton, {zIndex: 10}]}>
              <Text style={{fontSize: wp(4.5), color: 'grey'}}>X</Text>
            </TouchableOpacity>
            <Text style={styles.modalTitle}>Enter Details</Text>

            {/* Name Field */}

            <View style={{marginTop: 20}}>
              <Text
                style={{
                  fontWeight: '600',
                  fontSize: 18,
                  marginLeft: 10,
                  marginVertical: 5,
                }}>
                Description
              </Text>
              <TextInput
                style={{
                  // height: hp(0),
                  width: '100%',
                  borderRadius: 5,
                  marginTop: 10,

                  paddingHorizontal: 15,
                  borderWidth: 0.5,
                }}
                placeholder="Textarea"
                label="Text"
                value={textarea}
                multiline={true}
                onChangeText={text => settextarea(text)}
              />
            </View>
            <View style={{marginTop: hp(4), alignItems: 'center'}}>
              <TouchableOpacity
                style={[styles.btn3, {height: hp(5), width: wp(33)}]}
                onPress={() => {
                  console.log();
                }}>
                <Text
                  style={{fontSize: wp(4), fontWeight: '500', color: 'white'}}>
                  Submit
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      <BottumTab />
    </View>
  );
};
export default Details;
