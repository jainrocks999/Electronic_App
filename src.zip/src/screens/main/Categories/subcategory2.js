import {View, Text, StyleSheet} from 'react-native';
import React, {useEffect, useState} from 'react';
import AntDesign from 'react-native-vector-icons/AntDesign';
import AsyncStorage from '@react-native-async-storage/async-storage';
import BottumTab from '../../../compoents/BottumTab';
import {FlatList, TouchableOpacity} from 'react-native-gesture-handler';
import {Image} from 'react-native-elements';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import {useNavigation} from '@react-navigation/native';
import {useDispatch, useSelector} from 'react-redux';
import Loader from '../../../compoents/Loader';
import Imagepath from '../../../compoents/Imagepath';
import {
  addwishlist1,
  productDetail,
  productsbycategories,
} from '../../../redux/slice/Homesclice';
const Subcategory2 = ({route}) => {
  const navigation = useNavigation();

  const isLoading = useSelector(state => state?.home?.loading);
  const product = useSelector(state => state.home.catbyproduct);

  const dispatch = useDispatch();

  const addWishList = async item => {
    const token = await AsyncStorage.getItem('Token');
    const userid = await AsyncStorage.getItem('user_id');
    await dispatch(
      addwishlist1({
        user: userid,
        id: item.id,
        token: token,
        isadd: item.is_wishlist,
        // category:item.category_id,
        url: 'wishlist-product-add',
        // navigation,
      }),
    );

    console.log('item.is_wishlist,', item.is_wishlist);

    {
      isLoading == false
        ? await dispatch(
            productsbycategories({
              id: userid,
              token: token,
              category: item.category_id,
              url: 'category-by-product',
              navigation,
            }),
          )
        : null;
    }
  };
  const handleDetail = async item => {
    const token = await AsyncStorage.getItem('Token');
    const userid = await AsyncStorage.getItem('user_id');
    await dispatch(
      productDetail({
        user: userid,
        id: item.id,
        token: token,

        url: 'fetch-single-product',
        navigation,
      }),
    );
  };

  //   const filteredProducts = products.filter((product) =>{
  //   const productName = product.name.toLowerCase();
  // });

  const removeHtmlTags = str => {
    return str?.replace(/<\/?[^>]+(>|$)/g, '');
  };

  return (
    <View style={{flex: 1, backgroundColor: 'white'}}>
      {isLoading ? <Loader /> : null}
      <View style={styles.header}>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          <AntDesign
            onPress={() => navigation.goBack()}
            name="arrowleft"
            size={wp(5.9)}
            color="white"
          />
          <View style={{marginLeft: wp(4)}}>
            <Text style={styles.txt}>Products</Text>
          </View>
        </View>
        <View style={{marginLeft: wp(45)}}></View>
      </View>
      <View
        style={{
          flex: 1,
          marginTop: hp(1),
        }}>
        {product != 0 ? (
          <FlatList
            data={product}
            numColumns={2}
            keyExtractor={(item, index) => index.toString()}
            renderItem={({item, index}) => {
              return (
                <View style={styles.cardView}>
                  <View style={styles.imgcontainer}>
                    <TouchableOpacity
                      style={{
                        // position: 'absolute',
                        // top: 5,
                        right: 0,
                        left: 0,
                        zIndex: 10,
                        height: hp(3.5),
                        width: '100%',
                        backgroundColor: '#f1f1f1',
                        borderTopRightRadius: wp(2),
                        borderTopLeftRadius: wp(2),
                      }}
                      onPress={() => addWishList(item)}>
                      <AntDesign
                        name="hearto"
                        style={[
                          styles.iconic,
                          {
                            color: item.is_wishlist ? 'red' : 'grey',
                            marginLeft: '4%',
                            marginTop: hp(0.2),
                          },
                        ]}
                      />
                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => handleDetail(item)}>
                      <Image
                        style={styles.img}
                        source={{uri: `${Imagepath.Path}${item.images}`}}
                      />
                    </TouchableOpacity>
                  </View>
                  <Text style={styles.txt2}>{item.name}</Text>
                  <View style={{marginTop: 5, marginHorizontal: 15}}>
                    <Text>
                      {removeHtmlTags(item.description)
                        ?.split('\n')
                        .filter(line => line.trim())[0]
                        ?.substring(0, 30)}
                      ...{' '}
                    </Text>
                  </View>
                  <View style={styles.priceCOntainer}>
                    {item.special ? (
                      <>
                        <Text style={[styles.Price, {color: 'black'}]}>
                          {item.special}
                        </Text>
                        <Text
                          style={[
                            styles.Price,
                            {
                              textDecorationLine: 'line-through',
                              fontSize: wp(3),
                              fontWeight: 'bold',
                              marginLeft: wp(1),
                              color: 'red',
                            },
                          ]}>
                          ₹ {item.sale_price}
                        </Text>
                      </>
                    ) : (
                      <Text style={[styles.Price, {color: 'black'}]}>
                        ₹ {item.sale_price}
                      </Text>
                    )}
                    <Text
                      style={[
                        styles.Price,
                        {
                          fontSize: wp(3),
                          fontWeight: 'bold',
                          marginTop: 5,
                          marginBottom: 10,
                          color: 'grey',
                        },
                      ]}>
                      Ex Tax:{' '}
                      <Text style={{textDecorationLine: 'line-through'}}>
                        ₹ {item.price}
                      </Text>
                    </Text>
                  </View>
                </View>
              );
            }}
          />
        ) : (
          <View
            style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
            <Text>{'No product found'}</Text>
          </View>
        )}
      </View>
      <BottumTab />
    </View>
  );
};

export default Subcategory2;
const styles = StyleSheet.create({
  header: {
    height: hp(7),
    backgroundColor: '#18314F',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: wp(5),
    flexDirection: 'row',
  },
  txt: {
    fontSize: wp(4.5),
    color: 'white',
  },
  cardView: {
    //  paddingVertical:hp(1),
    //  paddingHorizontal:wp(2),
    backgroundColor: '#e6f0f2',
    margin: wp(1),
    // marginVertical: wp(1),
    width: wp(48),
    // marginHorizontal: wp(1),
    borderRadius: wp(2),
    shadowColor: 'black',
    shadowOpacity: 0.05,
  },
  cardsView: {
    backgroundColor: '#e6f0f2',
    width: wp(35),
    marginHorizontal: wp(2),
    borderRadius: wp(2),
    shadowColor: 'black',
    shadowOpacity: 0.05,
  },
  loadMoreButtonText: {
    color: 'black',
  },
  CardContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: wp(1),
    marginHorizontal: wp(2),
  },
  imgcontainer: {
    height: wp(40),
    width: '100%',
    // alignSelf: 'center',
    // marginTop: hp(5),
  },
  imagecontainer: {
    height: wp(20),
    width: wp(30),
    // alignSelf: 'center',
    // margin:10,
  },
  img: {
    height: '100%',
    width: '100%',
  },

  txt2: {
    alignSelf: 'center',
    marginTop: hp(5),
    fontSize: wp(4),
    fontWeight: '500',
    color: 'black',
  },
  txt3: {
    alignSelf: 'center',
    marginTop: wp(2),
    fontSize: wp(4),
    fontWeight: '300',
    color: 'black',
  },
  btn: {
    borderRadius: wp(1),
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    width: wp(22),
    height: hp(3.5),
    borderColor: 'grey',
    alignSelf: 'center',
    marginTop: hp(3),
    backgroundColor: '#0f3a8d',
  },
  priceCOntainer: {
    alignItems: 'center',
    //justifyContent:'space-between',
    marginTop: hp(2),
    alignSelf: 'center',
  },
  Price: {
    fontSize: wp(5),
    alignSelf: 'center',
    fontWeight: '500',
    color: 'black',
  },

  searchContainer: {
    backgroundColor: 'white',
  },
  searchBarContainer: {
    backgroundColor: 'white',
    borderBottomColor: 'white',
    borderTopColor: 'white',
  },
  searchBarInputContainer: {
    backgroundColor: 'white',
  },
  icon2: {
    fontSize: wp(7),
    position: 'absolute',
    top: -hp('69%'),
  },
  iconic: {
    // marginVertical:hp('-10%'),
    fontSize: wp(6.7),
    position: 'absolute',
  },
});
