
export default BASEURLS = {
    mainUrl: 'https://ecom.craftsweb.co.in/public/api/v1/',
  };
  