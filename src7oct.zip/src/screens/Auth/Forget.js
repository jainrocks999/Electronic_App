
import { Image, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import React, { useEffect, useState } from 'react'
import { heightPercentageToDP as hp, widthPercentageToDP as wp } from 'react-native-responsive-screen'
import Input from '../../compoents/Input'
import Button from '../../compoents/Button'
import { useDispatch, useSelector } from 'react-redux'
import Api from '../../redux/Api'
import OtpInputs from 'react-native-otp-inputs';
import { useNavigation } from '@react-navigation/native'
import AsyncStorage from '@react-native-async-storage/async-storage'
const Forget = () => {
    const dispatch = useDispatch()
    const navigation = useNavigation()
    const [isFocused, setIsfocused] = useState(true)
    const [otp, setOtp] = useState('');

  const handleVerifyOtp = () => {
    // Handle OTP verification logic
    if (otp.length === 4) {
      console.log('Entered OTP:', otp);
      // You can navigate to another screen or validate OTP here
    } else {
      alert('Please enter a valid 4-digit OTP');
    }
  };

    return (
        <View style={styles.container}>
            <View style={styles.logoConatainer}>
            <Image
            style={styles.img}
            source={{

            }}
          />
        </View>
        <View style={styles.infoTextContainer}>
          <Text style={styles.login}>Forget Your Passwod</Text>
          <View style={{ width: wp(60), alignSelf: 'center' }}>
            <Text
              style={{
                textAlign: 'center',
                marginVertical: wp(1),
                fontSize: wp(4),
                fontStyle: 'italic',
                color: 'grey',
              }}>
              We will send you an email to reset your password.
            </Text>
            <OtpInputs
        handleChange={handleVerifyOtp}
        numberOfInputs={4}  // 4 digit OTP के लिए
        autofillFromClipboard={false}  // क्लिपबोर्ड से ऑटोफिलिंग डिसेबल कर सकते हैं
        style={styles.otpContainer}
        inputStyles={styles.input}
      />
          </View>
          <View style={styles.line}></View>
        </View>
             <View style={{ marginHorizontal: 15 }}>
                 
                
            </View>
            
            <View style={{ marginTop: 50 }}>
               

<TouchableOpacity
            style={{
                height: hp('7%'),
               
            
                marginHorizontal: wp('3%'),
                backgroundColor: isFocused ? '#0f3a8d' : '#0d52d6',
                elevation: 5,
                flexDirection: 'row',
                borderRadius: hp('.50%'),
                flexDirection: 'row',
                justifyContent: 'center'
            }}
            activeOpacity={0.2}
            onFocus={() => { setIsfocused(true) }}
            onBlur={() => setIsfocused(false)}
           
        >
            <Text
                style=
                {{
                    fontSize: hp('3%'),
                    fontWeight: 'bold',
                    color: 'white',
                    alignSelf: "center",
                }}
            >Submit</Text>
        </TouchableOpacity>

            </View>
       
        </View>
    )
}

export default Forget

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white'
    },
    otpContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
      },
      input: {
        borderWidth: 1,
        borderColor: '#000',
        padding: 10,
        width: 50,
        height: 50,
        textAlign: 'center',
        fontSize: 18,
        borderRadius: 8,
      },
    logoConatainer: {

        width: '100%',
        height: hp(20), // Updated to a number

    },
    infoTextContainer: {
        marginHorizontal: '5%',
        marginVertical: '8%'
    },
    login: {
        fontSize: hp(4), // Updated to a number
        fontWeight: 'bold',
        color: 'grey'
    },
    img: {
        height: '100%',
        width: '100%',
        resizeMode: 'contain'
    },
    info: {
        fontSize: hp(2), // Updated to a number
        fontWeight: '400',
        color: 'grey',
    },
    login: {
          fontSize: wp('6%'),
          fontWeight: 'bold',
          color: 'black', //'#a26a39',
          fontStyle: 'italic',
          alignSelf: 'center',
          marginTop: wp(6),
        },
    errorText: {
        color: 'red',
        marginHorizontal: '5%',

    },
});

