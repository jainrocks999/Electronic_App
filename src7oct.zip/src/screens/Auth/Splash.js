import { View, Text,Image } from 'react-native'
import React, { useEffect } from 'react'
import {
    heightPercentageToDP as hp,
    widthPercentageToDP as wp,
  } from 'react-native-responsive-screen';
import AsyncStorage from '@react-native-async-storage/async-storage'
import { useDispatch } from 'react-redux';
const Splash = ({navigation}) => {
  const dispatch =useDispatch();
  useEffect(() => {
    dispatch({
        type: 'openCart/genrateToken',
    })

}, [])
useEffect(()=>{
    setTimeout(() => {
        goToto();
    }, 2000);
    const goToto=async()=>{
        const Token=await AsyncStorage.getItem('ctoken');
        const token12 = await AsyncStorage.getItem('token');
        console.log('data are geting ...',token12);
        
        if(Token==null || Token==''){
            navigation.navigate('Login');
        }
        else{
            navigation.navigate('Home');
        }
     console.log('gettying token ',Token);
     
    }
})
  return (
<View style={{flex: 1, alignItems: 'center', justifyContent: 'center',backgroundColor:'#18314F'}}>
<View
          style={{
            alignItems: 'center',
            alignContent: "center",
            justifyContent: 'center',
          }}>
          <Image
            style={{
              height: hp(20),
              width: wp(60),
              tintColor:'white'
            }}
            source={require('../../assests/ecom.png')}
          />
        </View>
    </View>
  )
  }
export default Splash

// import { View, Text,Image } from 'react-native'
// import React, { useEffect } from 'react'
// import {
//     heightPercentageToDP as hp,
//     widthPercentageToDP as wp,
//   } from 'react-native-responsive-screen';
// import AsyncStorage from '@react-native-async-storage/async-storage'
// import { useDispatch } from 'react-redux';
// const Splash = ({navigation}) => {
//   const dispatch =useDispatch();
// useEffect(() => {
//   const checkToken = async () => {
//     try {
//       const token = await AsyncStorage.getItem('token');
//       const ctoken = await AsyncStorage.getItem('ctoken');

//       if (!token || !ctoken) {
//         // No valid tokens found, navigate to login

//         setTimeout(() => {
//           navigation.replace('Login');
//               }, 2000);
       
//       } 
//       if (!token) {
      
//         await generateToken();
//       } else {
       
//         const tokenExpired = await isTokenExpired();
//         if (tokenExpired) {
//           await generateToken(); 
//         }
//       }
//       setTimeout(() => {
//         navigation.replace('Home');
//             }, 2000);
    
     
//     } catch (error) {
//       console.error('Error checking token: ', error);
//     }
//   };

//   checkToken(); // Run token check on splash screen load
// }, []);

// // Function to generate the token (same API call you provided)
// const generateToken = async () => {
//   try {
//     var formdata = new FormData();
//     formdata.append('username', 'Default');
//     formdata.append(
//       'key',
//       'J1yMIZch7GvCQQ8u1CSkGO62r2458XYYcczXmimGGFM2SMavnUJa8eJEQ2R6mCf2UHhtOQDrw5q1ZNP0P0uQwzRu5jAOSXhZJLe7sTl3lCprfJRk5fuU4blx246uLNPxKezlivEuEzOkv5MZDo4xVftPISm3YX1gbVF0INbuD7L2Qlo7COnsFk7HcbBwxJTqNcApJ6oXKfBmcSEraLI3ZY0ajad8ZS8jwkygsuIXciKEDcwIZyXcknIF75iX0utf',
//     );

//     var requestOptions = {
//       method: 'POST',
//       body: formdata,
//       redirect: 'follow',
//     };

//     const response = await fetch(
//       'https://ecom.forebearpro.co.in/upload/index.php?route=api/account/login',
//       requestOptions,
//     );
//     const result = await response.text();
//     const res = JSON.parse(result);

//     if (res?.success) {
      
//       const token = res?.api_token;
//       const expiresIn = 3600;
//       const expirationTime = new Date().getTime() + expiresIn * 1000;

//       await AsyncStorage.setItem('token', token);
//       await AsyncStorage.setItem('tokenExpiration', expirationTime.toString());
//     }
//   } catch (error) {
//     console.error('Error generating token: ', error);
//   }
// };


// const isTokenExpired = async () => {
//   const expirationTime = await AsyncStorage.getItem('tokenExpiration');
//  console.log('time gfmg...',expirationTime);
 
 
//   const currentTime = new Date().getTime();
  
//   console.log('current time ...',currentTime);
//   console.log('date....',new Date());
  
  
//   if (!expirationTime || currentTime > parseInt(expirationTime)) {
//     return true;
//   }
//   return false;
// };

//   return (
// <View style={{flex: 1, alignItems: 'center', justifyContent: 'center',backgroundColor:'#18314F'}}>
// <View
//           style={{
//             alignItems: 'center',
//             alignContent: "center",
//             justifyContent: 'center',
//           }}>
//           <Image
//             style={{
//               height: hp(20),
//               width: wp(60),
//               tintColor:'white'
//             }}
//             source={require('../../assests/ecom.png')}
//           />
//         </View>
//     </View>
//   )
//   }
// export default Splash

