import { Image, KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import React, { useEffect, useState } from 'react'
import { heightPercentageToDP as hp, widthPercentageToDP as wp } from 'react-native-responsive-screen'
import Input from '../../compoents/Input'
import Button from '../../compoents/Button'
import { useDispatch, useSelector } from 'react-redux'
import Api from '../../redux/Api'
import { TextInput } from 'react-native-gesture-handler'
import { useNavigation } from '@react-navigation/native'
import AsyncStorage from '@react-native-async-storage/async-storage'
import Loader from '../../compoents/Loader'
const Login = () => {
    const dispatch = useDispatch()
    const navigation = useNavigation()
    isLoading = useSelector(state=>state.data?.isLoading)
    const [inputs, setInputs] = useState({
        email: '',
        password: ''
    })
    const [errors, setErrors] = React.useState({});
    const [isValid, setIsValid] = useState(true);
    const isEmailValid = (email) => {
  
        const emailRegex = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;
        return emailRegex.test(email);
    };
    const isPasswordValid = (password) => {
   
        // const hasUppercase = /[A-Z]/.test(password);
        // const hasLowercase = /[a-z]/.test(password);
        // const hasDigit = /\d/.test(password);
        // return (
        //     hasUppercase &&
        //     hasLowercase &&
        //     hasDigit
        // );
        return true
    };
    const handleValidation = () => {
        const isEmailValidated = isEmailValid(inputs?.email);
        const isPasswordValidated = isPasswordValid(inputs?.password);
        if (isEmailValidated) {
            setIsValid(true);
            login();
        } else {
            setIsValid(false);
            alert('Invalid email id.');
        }
    };
    
    const toke = useSelector(state => state.data.token)


    // useEffect(() => {
    //     dispatch({
    //         type: 'openCart/genrateToken',
    //     })

    // }, [])
    const handleInput = (text, input) => {
        setInputs(prev => ({ ...prev, [text]: input }))
    }
    const handleError = (error, input) => {
        setErrors(prevState => ({ ...prevState, [input]: error }));
    };
    const login = async () => {
        const token = await AsyncStorage.getItem('token')

        dispatch({
            type: "openCart/loginRequest",
            token: token,
            user: inputs,
            navigation
        })
    }
    return (
        <View style={styles.container}>
             {isLoading?<Loader/> :null }
             

             <KeyboardAvoidingView
    behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    style={{ flex: 1 }}
  >
    <ScrollView
      contentContainerStyle={{ flexGrow: 1 }}
      showsVerticalScrollIndicator={false}
    >

            <View style={styles.logoConatainer}>
                <Image style={styles.img} source={require('../../assests/ecom.png')} />
            </View>

            <View style={styles.infoTextContainer}>
                <Text style={styles.login}>Login</Text>
                <Text style={styles.info}>Please enter the details below to continue</Text>
            </View>
            <View style={{ marginHorizontal: 15 }}>
                <Input
                    onChangeText={(input) => { handleInput('email', input) }}
                    value={inputs.email}
                    onFocus={() => handleError(null, 'email')}
                    iconName="email-outline"
                    label="Email"
                    placeholder="Enter your email address"
                    error={errors.email}
                />
              
            </View>
            {!isValid && (
                <Text style={styles.errorText}>
                    Please enter a valid email and password.
                </Text>
            )}
            <View style={{ marginTop: 50 }}>
                <Button onPress={() => {
                    handleValidation()
                }} name='Login' />
            </View>
            <Text onPress={() => navigation.navigate('Forget')} style={{
                alignSelf: 'flex-end',
                marginRight: '5%',
                fontSize: hp('2.4%'),
                color: 'grey',
                marginTop: 10
            }}>Forgot password ?</Text>

            <View style={{
                alignContent: 'center',
                alignItems: "center",
                textAlign: 'center',
                marginVertical: hp('5%'),
                justifyContent: "center",
                flexDirection: 'row'
            }}>
                <Text
                >Dont't have an account ?
                </Text>
                <TouchableOpacity onPress={() => navigation.navigate('Register')}>
                    <Text style={{ color: '#0f3a8d', }}> Sign Up!</Text>
                </TouchableOpacity>
            </View>
            </ScrollView>
            </KeyboardAvoidingView>
        </View>
    )
}

export default Login

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white'
    },
    logoConatainer: {
        marginTop:20,
        width: '100%',
        height: hp(15), // Updated to a number
    },
    infoTextContainer: {
        marginHorizontal: '5%',
        marginVertical: '8%'
    },
    login: {
        fontSize: hp(4), // Updated to a number
        fontWeight: 'bold',
        color: 'grey'
    },
    img: {
        height: '100%',
        width: '100%',
        resizeMode: 'contain'
    },
    info: {
        fontSize: hp(2), // Updated to a number
        fontWeight: '400',
        color: 'grey',
    },
    errorText: {
        color: 'red',
        marginHorizontal: '5%',

    },
});

