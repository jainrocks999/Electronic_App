import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  FlatList,
  Image,
  TouchableOpacity,
  Keyboard,
} from 'react-native';
import styles from './styles';
import BottumTab from '../../../compoents/BottumTab';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Icon from 'react-native-vector-icons/AntDesign';
import { useDispatch, useSelector } from 'react-redux';
import Loader from '../../../compoents/Loader';
import { call } from 'redux-saga/effects';
  const SearchBar = ({ navigation, route }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const products = useSelector((state) => state.data.Searchbar);

  console.log('gfdgdfgdfgfddg',products);
  
const isLoading=useSelector(state=>state.data?.isLoading1)
  const [input, setInput] = useState('');
  const seachText = route.params?.searchText;
  const dispatch = useDispatch();
  const typingTimeoutRef = useRef(null);

  console.log('islodsinffnd',isLoading);
  
  // useEffect(() => {
  //   const delay = 1500;
  //   const deBounce = setTimeout(() => {
  //     handleSearchbar();
  //   }, delay);
  //   return () => {
  //     clearTimeout(deBounce);
  //   };
  // }, [input]);



  const handleInputChange = (text) => {
    setInput(text);

    // Clear the previous timeout when the user types again
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }

    // Set a new timeout to call the API after a delay
    typingTimeoutRef.current = setTimeout(() => {
      if (text.trim() === '') {
        console.log('Input cleared, no API call');
      } else {
        // Hide the keyboard and call the search API after delay
        Keyboard.dismiss();
        handleSearchbar(text);
      }
    }, 500); // Adjust delay (500ms) as per your requirement
  };
  const handleSearchbar = async (text) => {
  
    
    if (input.trim() === '') {
      console.log('gdsfsgfsg');
      
      return;
    }else{
      console.log('gdsfsgfsg4232');
      // Keyboard.dismiss();
    const token = await AsyncStorage.getItem('token');
    dispatch({
      type: 'openCart/fetchsearchbar',
      token: token,
      search: input,
    });
  }
  };


  
  const handleDetail = async (id) => {
    const token = await AsyncStorage.getItem('token');
    dispatch({
      type: 'openCart/fetchProductDetail',
      token: token,
      id: id,
      navigation,
    });
  };
  return (
    <View style={{ flex: 1, backgroundColor: 'white' }}>
      {isLoading?<Loader/>:null}
      <View style={styles.container}>
        <View style={{
          flexDirection: 'row',
        }}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              paddingHorizontal: 20,
            }}>
            <AntDesign
              onPress={() => navigation.goBack()}
              name="arrowleft"
              size={wp(5)}
              color="grey"
            />
          </View>
          <View style={styles.input}>
            <Icon name="search1" style={styles.icon} />
            <TextInput
              style={styles.textInput}
              placeholderTextColor={'grey'}
              placeholder="Search Products"
              returnKeyType='done'
              // onChangeText={text => {setInput(text);
              //   handleSearchbar(text);
              // }}
             onChangeText={(text)=>handleInputChange(text)}
             
            />
          </View>
        </View>
        {input.trim() === ''||products == undefined ? ( // Check if input is empty
          <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
            <Text>No search query entered</Text>
          </View>
        ) : (
          <View style={styles.cardView}>
            <View style={styles.imgcontainer}>
              <TouchableOpacity
                onPress={() => handleDetail(products.product_data.product_id)}
              >
                {products?.product_data?.thumb ? (
                  <Image style={styles.img} source={{ uri: products.product_data.thumb }} />
                ) : (
                  <Image
                    style={styles.img}
                    source={require('../../../assests/noimg.jpeg')}
                  />
                )}
              </TouchableOpacity>
            </View>
            <Text style={styles.txt2}>{products?.product_data?.name}</Text>
            <View style={{ marginTop: 15, marginHorizontal: 5 }}>
              <Text> {products?.product_data?.description} </Text>
            </View>
            <View style={styles.priceCOntainer}>
              <Text style={[styles.Price, { marginLeft: wp(10) }]}>
                {products?.product_data?.price}
              </Text>
              <Text
                style={[
                  styles.Price,
                  {
                    textDecorationLine: 'line-through',
                    fontSize: wp(3),
                    fontWeight: 'bold',
                    marginLeft: wp(1),
                    color: 'red',
                  },
                ]}
              >
                {products?.product_data?.tax}
              </Text>
            </View>
          </View>
        )}
      </View>
      <BottumTab/>
    </View>
  );
};
export default SearchBar;