import React, { useEffect, useState } from 'react';
import { FlatList, Image, Text, ToastAndroid, TouchableOpacity, View } from 'react-native';
import { SearchBar } from 'react-native-elements';
import styles from './styles';
import AntDesign from 'react-native-vector-icons/AntDesign';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
import { useNavigation } from '@react-navigation/native';
import BottumTab from '../../../compoents/BottumTab';
import { useDispatch, useSelector } from 'react-redux';
import { ScrollView } from 'react-native-gesture-handler';
import he from 'he';
import Loader from '../../../compoents/Loader';

const ProductList = ({ navigation }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const detail = useSelector(state => state.data.productDetails);
  const products = useSelector((state) => state.data?.products);
  const isLoading=useSelector(state=>state.data.isLoading)
  const dispatch = useDispatch();
  const [loading, setLoading] = useState(false);
  const [data,setData]=useState(products)
  const [limit, setLimit] = useState(10);
  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    const token = await AsyncStorage.getItem('token');
    dispatch({
      type: 'openCart/fetchProducts',
      token: token,
      page: 'products',
      navigation,
    });
  };
const productsonReached = async () => {


  try {
    setLoading(true);
    const token = await AsyncStorage.getItem('token');
    const newLimit = limit + 10; 
   

    const requestOptions = {
      method: 'GET',
      redirect: 'follow',
    };

    const response = await fetch(
      `https://ecom.forebearpro.co.in/upload/index.php?route=api/custom/productctrl.productlistNew&api_token=${token}&limit=${newLimit}`,
      requestOptions
    );

    if (!response.ok) {
      throw new Error('Failed to fetch products');
    }

    const result = await response.json(); 
    console.log('Data fetched by product API response', result);
    setLimit(result.limit);
    // setData(prevProducts => {
    //   const newProducts = result?.products.filter(newProduct => 
    //     !prevProducts.some(existingProduct => existingProduct.name === newProduct.name) // Filter out duplicates based on 'name'
    //   );
    //   return [...prevProducts, ...newProducts]; // Add only new products
    // });

    if (!result?.products || result.products.length === 0) {
      
  
      ToastAndroid.show('No new products to add', ToastAndroid.SHORT);
      return; 
    }

   
    const newProducts = result.products.filter(newProduct => 
      !data.some(existingProduct => existingProduct.name == newProduct.name) // Filter out duplicates based on 'name'
    );

    if (newProducts.length == 0) {
      
      ToastAndroid.show('No more products available', ToastAndroid.SHORT);
    } else {
    
      setData(prevProducts => [...prevProducts, ...newProducts]);
    }

  } catch (error) {
    console.error('Error fetching products', error);
  } finally {
    setLoading(false); 
  }
};




  const addWishList = async id => {
    const token = await AsyncStorage.getItem('token');
    dispatch({
      type: 'openCart/fetchAddWishList',
      token: token,
      id: id,
      navigation,
    });
    console.log('this is id from productlist page', id);
  };
  const handleDetails = async (id) => {
    const token = await AsyncStorage.getItem('token');
    await dispatch({
      type: 'openCart/fetchProductDetail',
      token: token,
      id: id,
      navigation,
    });
  };
  const handleSearch = (text) => {
    setSearchQuery(text);
  };
  const filteredProducts = data.filter((product) => {
    const productName = product.name.toLowerCase();
    const search = searchQuery.toLowerCase();
    return productName.includes(search);
  });

  return (
    <View style={{ flex: 1, backgroundColor: 'white' }}>
      {isLoading||loading?<Loader/>:null}
      <View style={styles.conatainer}>
        <View style={styles.header}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <AntDesign
              onPress={() => navigation.goBack()}
              name="arrowleft"
              size={wp(5)}
              color="white"
            />
            <Text style={styles.txt}>Product List</Text>
          </View>
        </View>
        <View style={styles.searchContainer}>
          <SearchBar
            placeholder="Search..."
            onChangeText={handleSearch}
            value={searchQuery}
            containerStyle={styles.searchBarContainer}
            inputContainerStyle={styles.searchBarInputContainer}
            inputStyle={styles.searchBarInput}
          />
        </View>
        {/* <ScrollView> */}
          <FlatList
            data={filteredProducts}
            onEndReached={() => productsonReached()}
            onEndReachedThreshold={1}
            numColumns={2}
            keyExtractor={(item, index) => index.toString()}
            renderItem={({ item, index }) => {

              const decodedProductName = he.decode(item.name);
              return (
                <View style={styles.cardView}>
                  <TouchableOpacity
                      onPress={() => { addWishList(item.product_id) }}
                    >
                      <AntDesign name="hearto" style={styles.iconic} />
                    </TouchableOpacity>
                  <View style={styles.imgcontainer}>
                    <TouchableOpacity
                      onPress={() => handleDetails(item.product_id)}
                    >
                      <Image style={styles.img} source={{ uri: item.image }} />
                    </TouchableOpacity>
                    
                  </View>
                  <Text style={styles.txt2}>{decodedProductName}</Text>
                  <View style={{ marginTop: 15, marginHorizontal: 5 }}>
                    <Text> {item.description} </Text>
                  </View>
                  <View style={styles.priceCOntainer}>
                    {item.special ? (
                      <>
                        <Text style={[styles.Price, { color: 'black' }]}>
                          {item.special}
                        </Text>
                        <Text
                          style={[
                            styles.Price,
                            {
                              textDecorationLine: 'line-through',
                              fontSize: wp(3),
                              fontWeight: 'bold',
                              marginLeft: wp(1),
                              color: 'red',
                            },
                          ]}
                        >
                          {item.price}
                        </Text>
                      </>
                    ):(
                      <Text style={[styles.Price, { color: 'black' }]}>
                        {item.price}
                      </Text>
                    )}
                    <Text
                      style={[
                        styles.Price,
                        {
                          fontSize: wp(3),
                          fontWeight: 'bold',
                          marginTop: 5,
                          marginBottom: 10,
                          color: 'grey',
                        },
                      ]}
                    >
                      Ex Tax: {item.tax}
                    </Text>
                  </View>
                </View>
              );
            }}
          />
        {/* </ScrollView> */}
      </View>
      <BottumTab/>
    </View>
  );
};

export default ProductList;

