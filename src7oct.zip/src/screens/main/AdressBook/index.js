import {View, Text} from 'react-native';
import React from 'react';
import styles from './styles';

const AddressBook = () => {
  return (
    <View style={styles.container}>
      <Text>AddressBook</Text>
    </View>
  );
};

export default AddressBook;
