import {View, Text} from 'react-native';
import React from 'react';

const OrderDetails = () => {
  return (
    <View>
      <Text>OrderDetails</Text>
    </View>
  );
};

export default OrderDetails;
